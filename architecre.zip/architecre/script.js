
$(window).on('scroll', function () {
	if ($(window).scrollTop()) {
		$('nav').addClass('black');
	}
	
	else {
		$('nav').removeClass('black');
	}
})
$(document).ready(function () {
	$('.menu h4').click(function () {
		$("nav ul").toggleClass("active")
	})
})


new PureCounter({
	selector: ".purecounter",
	start: 0,
	end: 1000000,
	duration: 15,
	delay: 6,
	once: true,
	pulse: false,
	decimals: 0,
	legacy: true,
	filesizing: false,
	currency: false,
	formater: "us-US",
	separator: false
});

